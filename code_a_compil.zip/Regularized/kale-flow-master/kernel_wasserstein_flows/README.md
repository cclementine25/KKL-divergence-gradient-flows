Utilities to simulate wasserstein gradient flows of risk functionals based on
measure embeddings.
