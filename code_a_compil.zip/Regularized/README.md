# KKL_div

simulations.py contains the experiences with gradient flows
tests_mmd_kkl contains the experience where we plot the evolution of KKL for moving distributions

Ne servent à rien :
    -sanity_check.py
    -shapes.py
    -poubelle.py